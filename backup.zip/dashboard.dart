import 'package:flutter/material.dart';
import 'package:modul1_pemrograman_mobile/page/main_page.dart';
import 'login_page.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Dashboard extends StatefulWidget {
  const Dashboard({Key? key}) : super(key: key);

  @override
  _DashboardState createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {
  late String username;
  late String nama;


  @override
  void initState() {
    super.initState();
    name();
  }

  void name() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      username = prefs.getString('username')!;
      nama = prefs.getString('nama')!;
    });
  }

  void _logOut() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.remove('user');
    prefs.setString('username', username);
    prefs.setString('nama', nama);
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (c) => const Login()));
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Dashboard'),
        backgroundColor: Colors.indigo,
        actions: <Widget>[
          IconButton(icon: const Icon(Icons.logout), onPressed: _logOut)
        ],
      ),
      body: Center(
        child: Stack(
          children: [
            Center(
              child: Padding(
                padding: const EdgeInsets.only(top: 30.0),
                child: Column(
                  children: <Widget>[
                    const Text(
                    "Selamat Datang",
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w800,
                    ),
                    ),
                    Container(
                      margin: const EdgeInsets.all(10),
                      child: Expanded(
                        child: InkWell(
                          highlightColor: Colors.transparent,
                          splashColor: Colors.transparent,
                          onTap: (){
                            Navigator.push(context,
                              MaterialPageRoute(builder: (context) => const MainPage()));
                          },
                          child: Column(
                            children: const <Widget>[
                              Image(image: AssetImage("assets/images/doa.png"),
                              height: 300, width: 300,),
                              SizedBox(
                                height: 10,
                              ),
                              Text("Home",
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.bold
                              ),)
                            ],
                          ),
                        ),
                    )
                    )],
                ),
              ),
            ),

            DraggableScrollableSheet(
                initialChildSize: 0.1,
                minChildSize: 0.1,
                maxChildSize: 0.5,
                builder:
                    (BuildContext context, ScrollController scrollController) {
                  return Container(
                    decoration: const BoxDecoration(
                        color: Colors.lightBlue,
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(20),
                          topRight: Radius.circular(20),
                        )),
                    child: SingleChildScrollView(
                      controller: scrollController,
                      child: Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(15.0),
                            child: Container(
                              decoration: const BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.all(
                                    Radius.circular(20),
                                  )),
                              height: 10,
                              width: 100,
                            ),
                          ),
                          const Padding(
                            padding: EdgeInsets.only(top: 30.0, bottom: 10.0),
                            child: CircleAvatar(
                              radius: 50.0,
                              backgroundColor: Colors.yellow,
                            ),
                          ),
                          Text(
                            nama,
                            style: const TextStyle(
                              fontSize: 19,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          Text(
                            username,
                            style: const TextStyle(
                              fontSize: 17,
                              fontWeight: FontWeight.w300,
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                })],
        ),
    ),
    );
  }
}